﻿namespace RestSharpAPITests
{
    public class ContactObject
    {
        public string msg { get; set; }
        public Contact contact { get; set; }
    }
}